import React from 'react'
import Nav from './Nav'
import Mainn from './Mainn'
import Post from './Post'

const Home = () => {
  return (
    <div>
        <Nav/>
        <Mainn/>
        <Post/>
        <Post/>
        <Post/>
        <Post/>
    </div>
  )
}

export default Home