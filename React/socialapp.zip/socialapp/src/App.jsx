import './App.css'
import Home from './Components/Home/Home'
import { BrowserRouter,Route,Routes } from 'react-router-dom'
import LoginSignup from './Components/Login_and_signUp/Login_signup'
import Profile from './Components/Profile/Profile'
function App() {

  return (
    <BrowserRouter>
    <Routes>
      <Route path='/login' element={<LoginSignup />}/>
      <Route path='/' element={<Home />}/>
      <Route path='/profile' element={<Profile />}/>
    </Routes>
    </BrowserRouter>
  )
}

export default App
