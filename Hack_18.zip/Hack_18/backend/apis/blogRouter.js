const express = require('express');
const Blogs = require("../models/Blog");
const verifyToken = require('../middlewares/IsLoggedIn');
let router = express.Router();

// Route to verify if the user is logged in
router.get('/verifyLogin', verifyToken, (req, res) => {
    // If the middleware passed, it means the user is logged in
    res.send('verified')
});

router.get("/", async (req, res) => {
    try {
        let allBlogs = await Blogs.find({});
        res.status(200).json(allBlogs);
    }
    catch (e) {
        res.send(400).json({ msg: 'something went wrong' });
    }
})

//a specific type ka blog 
router.get("/:id", async (req, res) => {
    try {
        let allBlogs = await Blogs.find({});
        const { id } = req.params;
        const blog = allBlogs.find((blog) => blog.id == id);
        // console.log(blog);
        res.status(200).json(blog);
    }
    catch (e) {
        res.send(400).json({ msg: 'something went wrong' })
    }
})

router.post('/:id/add-comment', async (req, res) => {
    // const { id } = req.params;
    const { user, comment } = req.body;
    // console.log(user+"jkf"+comment);
    // console.log(typeof(id));
    try {
        // Find the blog post by ID
        let allBlogs = await Blogs.find({});
        const { id } = req.params;
        const blog = allBlogs.find((blog) => blog.id == id);
        // console.log(blog.Comments);
        if (!blog) {
            return res.status(404).json({ message: 'Blog not found' });
        }

        // Add the new comment to the blog post's Comments array
        await blog.Comments.push({ user, comment });

        // Save the updated blog post
        await blog.save();

        res.status(201).json({ message: 'Comment added successfully', blog });
    } catch (error) {
        console.error('Error adding comment:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// router.get("/lifestyle",async(req,res)=>{
//     try{
//         let techBlogs = await Blogs.find({ category: "lifestyle" });
//         res.status(200).json(techBlogs);
//     }
//     catch(e){
//         res.send(400).json({msg:'something went wrong'})
//     }
// })
// router.get("/all-blogs",async(req,res)=>{
//     try{
//         let techBlogs = await Blogs.find({ category: "tech" });
//         res.status(200).json(techBlogs);
//     }
//     catch(e){
//         res.send(400).json({msg:'something went wrong'})
//     }
// })
// router.get("/all-blogs",async(req,res)=>{
//     try{
//         let techBlogs = await Blogs.find({ category: "tech" });
//         res.status(200).json(techBlogs);
//     }
//     catch(e){
//         res.send(400).json({msg:'something went wrong'})
//     }
// })
// router.get("/all-blogs",async(req,res)=>{
//     try{
//         let techBlogs = await Blogs.find({ category: "tech" });
//         res.status(200).json(techBlogs);
//     }
//     catch(e){
//         res.send(400).json({msg:'something went wrong'})
//     }
// })
// router.get("/all-blogs",async(req,res)=>{
//     try{
//         let techBlogs = await Blogs.find({ category: "tech" });
//         res.status(200).json(techBlogs);
//     }
//     catch(e){
//         res.send(400).json({msg:'something went wrong'})
//     }
// })
module.exports = router;