const jwt=require('jsonwebtoken');
const TokenGenerator=function(data){
    data=JSON.stringify(data);
    const token =jwt.sign(data,"ye secret key h")
    return token;
}
module.exports=TokenGenerator