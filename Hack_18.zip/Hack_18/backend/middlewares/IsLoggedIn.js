    const jwt = require('jsonwebtoken');
    const verifyToken = (req, res, next) => {
        // Get token from cookies, headers, query parameters, or wherever you're sending it
        // console.log(req.cookies.token);
        const token = req.cookies.token;

        // If token is not provided
        // const token=false;
        if (!token) {
            return res.status(401).json({ success: false, message: 'Unauthorized: No token provided' });
        }

        try {
            // Verify the token
            const decoded = jwt.verify(token, 'ye secret key h'); // Verify with your secret key

            // Add the decoded user information to the request object for further processing
            req.user = decoded;

            // Call next middleware
            next();
        } catch (error) {
            // Token is invalid
            return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token' });
        }
    };
    module.exports=verifyToken;