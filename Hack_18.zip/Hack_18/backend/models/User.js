const mongoose = require('mongoose');
const bcrypt=require('bcryptjs');
const userSchmema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
        trim: true,
    },
    lastName: {
        type: String,
        required: false
    },
    email: {
        type: String,
        lowercase: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    }

})
userSchmema.pre('save', async function (next) {
    const user = this;
    if (!user.isModified('password')) {
        next();
    }
    else {
        try {
            const saltRound = await bcrypt.genSalt(10);
            user.password = await bcrypt.hash(user.password, saltRound)
        }
        catch(error){
            next(error);
        }
    }
})
let User = mongoose.model('User', userSchmema);
module.exports = User;