const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const blogSchema = new mongoose.Schema({
  id: String, 
  title: String,
  content: String,
  // author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  // createdAt: { type: Date, default: Date.now },
  category: String,
  Comments: [
    {
      user: String,
      comment: String,
    }
  ],
  likeCount: { type: Number, default: 0 },
  // other blog-related fields
});

const Blogs = mongoose.model('Blogs', blogSchema);
module.exports = Blogs;
