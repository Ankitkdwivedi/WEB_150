const TokenGenerator = require("../middlewares/jwtTokenGenerator");
const User = require("../models/User");
const router = require('express').Router();
const bcrypt=require('bcryptjs');
const verifyToken = require("../middlewares/IsLoggedIn");
router.post('/register', async (req, res) => {
    try {
        const data = req.body;
        // console.log(req.body);
        const existingUser = await User.findOne({ email: data.email });
        if (existingUser) {
            return res.json({ success: false, msg: `Email already exists` });
        }

        // const hashedPassword = await bcrypt.hash(data.password, 10);  //used in db 
        const user = await User({
            firstName: data.firstName,
            lastName: data.lastName,
            email: data.email,
            password: data.password,
        });

        await user.save();
        res.json({ success: true, msg: `Registration successful` });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, msg: `Internal Server Error` });
    }
});


router.post('/login', async (req, res) => {
    try {
        const data = req.body;
        const user = await User.findOne({ email: data.email });

        if (!user) {
            return res.json({ success: false, msg: `Account Doesn't Exist` });
        }

        const isMatch = await bcrypt.compare(data.password, user.password);
        // console.log(isMatch);

        if (!isMatch) {
            return res.json({ success: false, msg: 'Invalid Email / Password' });
        }

        const token = TokenGenerator(user);
        user.token = token;
        user.password = undefined;

        const options = {
            expires: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
            httpOnly: true,
        };

        res.status(200).json({
            success: true,
            msg: 'Logged In Successfully!',
            token,
            user
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, msg: 'Internal Server Error' });
    }
});


router.post('/logout', async(req, res) => {//do check why get is not working later
    res.clearCookie('token');
    res.status(200).json({ success: true, message: 'Logged out successfully' });
});
router.post('/ankit',verifyToken, (req,res)=>{
    res.send('IsLoggedIn to h')
})
module.exports = router;