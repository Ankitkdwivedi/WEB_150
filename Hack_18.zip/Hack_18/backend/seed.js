const { v4: uuidv4 } = require('uuid');
const Blog = require('./models/Blog');
const Review = require('./models/Review');
let dummy=[
    {
        id:uuidv4(),
        title: "Sample Blog 1",
        content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        catagory: "Sample Category 1",
        Comments: [
          { user: "User1", comment: "Comment 1 for Sample Blog 1" },
        ],
        likeCount: 10
      },
      {
        id:uuidv4(),
        title: "Sample Blog 2",
        content: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        catagory: "Sample Category 2",
        Comments: [
          { user: "User3", comment: "Comment 1 for Sample Blog 2" },
        ],
        likeCount: 5
      } 
]

// async function seedDB(){
//     await Blog.insertMany(dummy);
//     console.log('db done');
// }
// module.exports=seedDB;
// // Quotes.create(dummy);
// Sample data for blogs
// const blogsData = [
//     {
//         id:uuidv4(),
//       title: "First Blog",
//       content: "This is the content of the first blog.",
//       catagory: "Technology",
//       Comments: [
//         {
//             comment: "this is dummhy blog",
//             user:"adfdskfkdf",
//         }
//       ]
//     },
// //     {
// //         id:uuidv4(),
// //       title: "First Blog",
// //       content: "This is the content of the first blog.",
// //       catagory: "Technology",
// //       Comments: [
// //         {
// //           rating: 4,
// //           comment: "Great blog post!",
// //           user: "user1@example.com" // Replace with the email of the user who made the comment
// //         }
// //       ]
// //     },
// //     {
// //         id:uuidv4(),
// //       title: "First Blog",
// //       content: "This is the content of the first blog.",
// //       catagory: "Technology",
// //       Comments: [
// //         {
// //           rating: 4,
// //           comment: "Great blog post!",
// //           user: "user1@example.com" // Replace with the email of the user who made the comment
// //         }
// //       ]
// //     },
// //     {
// //         id:uuidv4(),
// //       title: "First Blog",
// //       content: "This is the content of the first blog.",
// //       catagory: "Technology",
// //       Comments: [
// //         {
// //           rating: 4,
// //           comment: "Great blog post!",
// //           user: "user1@example.com" // Replace with the email of the user who made the comment
// //         }
// //       ]
// //     },
// //     // Add more sample blogs as needed
//   ];
  
  // Sample data for users
//   const usersData = [
//     {
//       firstName: "John",
//       lastName: "Doe",
//       email: "user1@example.com",
//       password: "password1"
//     },
//     // Add more sample users as needed
//   ];
  
  // Sample data for comments (reviews)
//   const commentsData = [
//     {
//       rating: 5,
//       comment: "Awesome blog!",
//     },
//     {
//       rating: 5,
//       comment: "Awesome blog!",
//     },
//     {
//       rating: 3,
//       comment: "Awesome blog!",
//     },
//     {
//       rating: 2,
//       comment: "Awesome blog!",
//     },
//     // Add more sample comments as needed
//   ];
  
  const seed=async function(){
    await Blog.deleteMany({});
    await Blog.insertMany(dummy)
    .then(()=>console.log('successfully'));
    // await Review.insertMany(commentsData);
  }
  module.exports = seed;
  