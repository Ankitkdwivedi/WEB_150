const express = require('express');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');
const seedDb=require('./seed');
const app=express();
const cors = require('cors')
const blogRoutes=require("./apis/blogRouter");
const authRoutes=require("./authRoutes/authRoutes");
mongoose.connect('mongodb://127.0.0.1:27017/blog-app')
.then(()=>{console.log('db is connected');})
.catch(()=>{console.log("error in connection of db");})

//cors
app.use(cookieParser());
app.use(cors({origin:['http://localhost:5173']}));
app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use(blogRoutes);
app.use(authRoutes);
// seedDb();

const port=8080;
app.listen(port,()=>{
    console.log(`server is running fine on ${port}`);
})