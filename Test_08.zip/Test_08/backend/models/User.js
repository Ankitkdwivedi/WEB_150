const mongoose = require('mongoose');
const bcrypt=require('bcryptjs');
const userSchmema = new mongoose.Schema({
    gender:{
        type:String,
    },
    type:{
        type:String,
    },
    // age:{
    //     type:Number,
    //     required:true,
    // },
    // address:{
    //     type:String,
    //     requred:true,
    // },
    email: {
        type: String,
        lowercase: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    }

})
userSchmema.pre('save', async function (next) {
    const user = this;
    if (!user.isModified('password')) {
        next();
    }
    else {
        try {
            const saltRound = await bcrypt.genSalt(10);
            user.password = await bcrypt.hash(user.password, saltRound)
        }
        catch(error){
            next(error);
        }
    }
})
let User = mongoose.model('User', userSchmema);
module.exports = User;



