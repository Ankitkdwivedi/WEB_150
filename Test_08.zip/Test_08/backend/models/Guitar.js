const mongoose = require('mongoose');
const guitarSchema = new mongoose.Schema({
    type:{
        type:String,
        required:true,
    },
    color:{
        type:String,
        required:true,
    },
    material:{
        type:String,
        required:true,
    },
    brand:{
        type:String,

    },
    price: {
        type: String,
        required:true,
    },
    

},{timestamps:true});
let Guitar = mongoose.model('Guitar', guitarSchema);
module.exports = Guitar;



