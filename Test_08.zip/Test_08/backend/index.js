const express = require('express');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');
const app=express();
const cors = require('cors')
const authRoutes=require("./authRoutes/authRoutes");
const guitarRoutes=require("./apis/guitarRoutes");
mongoose.connect('mongodb://127.0.0.1:27017/guitar-app')
.then(()=>{console.log('db is connected');})
.catch(()=>{console.log("error in connection of db");})

app.use(cookieParser());
app.use(cors({origin:['http://localhost:5173']}));
app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use(authRoutes);
app.use(guitarRoutes);

const port=8080;
app.listen(port,()=>{
    console.log(`server is running fine on ${port}`);
})