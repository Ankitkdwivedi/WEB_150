const TokenGenerator = require("../middlewares/jwtTokenGenerator");
const User = require("../models/User");
const router = require('express').Router();
const bcrypt=require('bcryptjs');
const {verifyToken} = require("../middlewares/IsLoggedIn");
router.post('/register', async (req, res) => {
    try {
        const data = req.body;
        // console.log(req.body);
        const existingUser = await User.findOne({ email: data.email });
        if (existingUser) {
            return res.json({ success: false, msg: `Email already exists` });
        }

        const user = await User({
            gender: data.gender,
            type: data.type,
            email: data.email,
            password: data.password,
        });

        await user.save();
        res.json({ success: true, msg: `Registration successful` });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, msg: `Internal Server Error` });
    }
});


router.post('/login', async (req, res) => {
    try {
        const data = req.body;
        const user = await User.findOne({ email: data.email });

        if (user==null||!user) {
            return res.json({ success: false, msg: `Account Doesn't Exist` });
        }

        const isMatch = await bcrypt.compare(data.password, user.password);

        if (!isMatch) {
            return res.json({ success: false, msg: 'Invalid Email / Password' });
        }

        const token = TokenGenerator(user);
        user.token = token;
        user.password = undefined;
        res.cookie("jwt", token, {
        });

        res.status(200).json({
            success: true,
            msg: 'Logged In Successfully!',
            token,
            user
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, msg: 'Internal Server Error' });
    }
});


router.post('/logout',async(req, res) => {
    res.clearCookie('token');
    res.status(200).json({ success: true, message: 'Logged out successfully' });
});
router.post('/ankit',verifyToken, (req,res)=>{
    res.send('IsLoggedIn to h')
})
module.exports = router;