const TokenGenerator = require("../middlewares/jwtTokenGenerator");
const Guitar = require("../models/Guitar");
const router = require('express').Router();
router.get('/',async(req,res)=>{
    const all= await Guitar.find({});
    res.status(201).json(all);
})

router.post('/new',async(req,res)=>{
    const newg=req.body;
    await Guitar.create(newg);
    res.json({ success: true, msg: `Added successful` });
})
router.get('/:id',async(req,res)=>{
    const ids=req.params;
    // console.log(ids.id);
    await Guitar.deleteMany({_id:ids.id});
    res.json({ success: true, msg: `deleted Successfully successful` });
})

module.exports = router;













router.post('/register', async (req, res) => {
    try {
        const data = req.body;
        // console.log(req.body);
        const existingUser = await User.findOne({ email: data.email });
        if (existingUser) {
            return res.json({ success: false, msg: `Email already exists` });
        }

        const user = await User({
            firstName: data.firstName,
            lastName: data.lastName,
            email: data.email,
            password: data.password,
        });

        await user.save();
        res.json({ success: true, msg: `Registration successful` });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, msg: `Internal Server Error` });
    }
});